#!/usr/bin/env bash
#
# install.sh - Setup script for the Enhanced AutoDL Telegram Bot
#
# This script automates the installation of system dependencies,
# Python packages, virtual environment creation and systemd
# service installation. It should be executed on a host running a
# Debian/Ubuntu-based distribution with sudo privileges.

set -euo pipefail

APP_DIR="$(dirname "$(realpath "$0")")/.."
ENV_FILE="$APP_DIR/config/.env"
VENV_DIR="$APP_DIR/venv"
SERVICE_NAME="autodl-bot.service"

echo "Installing system packages..."
sudo apt-get update
sudo apt-get install -y python3-venv aria2 ffmpeg

# Create Python virtual environment if it does not already exist
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment in $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
fi

echo "Activating virtual environment and installing Python dependencies..."
"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install -r "$APP_DIR/requirements.txt"

echo "Ensuring logs and queue directories exist..."
mkdir -p "$APP_DIR/data/logs" "$APP_DIR/data/queue"

echo "Creating systemd service file..."
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME"
sudo bash -c "cat > $SERVICE_FILE" <<'SERVICE_EOF'
[Unit]
Description=AutoDL Telegram Bot Service
After=network.target

[Service]
Type=simple
User=${USER}
WorkingDirectory={{APP_DIR}}
ExecStart={{APP_DIR}}/venv/bin/python {{APP_DIR}}/src/autodl_bot.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
SERVICE_EOF

sudo sed -i "s|{{APP_DIR}}|$APP_DIR|g" "$SERVICE_FILE"

echo "Reloading systemd daemon and enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable --now "$SERVICE_NAME"

echo "Installation complete. You can view the logs with:\n  journalctl -u $SERVICE_NAME -f"