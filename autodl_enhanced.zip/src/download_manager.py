"""Download manager for the Enhanced AutoDL Telegram Bot.

This module is responsible for pulling tasks from the queue and
downloading them using yt‑dlp. It supports concurrent downloads,
respects global pause/resume commands, implements retry logic with
exponential backoff and keeps track of progress for real‑time status
reporting.
"""

from __future__ import annotations

import asyncio
import os
from typing import Dict, Optional

from yt_dlp import YoutubeDL

from .queue_manager import QueueManager, DownloadTask
from .utils import disk_monitor
from .utils.logger import get_logger
from .config_manager import Config


class DownloadManager:
    """Coordinate downloads for queued tasks.

    Parameters
    ----------
    queue_manager: QueueManager
        The queue manager responsible for persisting tasks.
    config: Config
        Loaded configuration with download directory, concurrency limit,
        cookie file, etc.
    """

    def __init__(self, queue_manager: QueueManager, config: Config):
        self.queue_manager = queue_manager
        self.config = config
        self.logger = get_logger(self.__class__.__name__)
        self.active_tasks: Dict[int, Dict[str, str]] = {}
        self.paused: bool = False
        self._workers: list[asyncio.Task] = []
        # To allow graceful shutdown
        self._stop_event = asyncio.Event()

    async def start(self) -> None:
        """Start worker tasks up to the configured concurrency limit."""
        # Reset stop flag
        self._stop_event.clear()
        self.logger.info(
            f"Starting download manager with {self.config.max_concurrent} workers"
        )
        for _ in range(self.config.max_concurrent):
            task = asyncio.create_task(self._worker_loop())
            self._workers.append(task)

    async def stop(self) -> None:
        """Signal all workers to stop and wait for them to finish."""
        self._stop_event.set()
        for worker in self._workers:
            worker.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()

    async def _worker_loop(self) -> None:
        """Continuously fetch and process tasks until stopped."""
        while not self._stop_event.is_set():
            # If paused, sleep briefly and retry
            if self.paused:
                await asyncio.sleep(2)
                continue
            # Check disk space before starting a new task
            if disk_monitor.is_low_disk(self.config.download_dir):
                self.logger.warning(
                    "Low disk space detected. Pausing downloads until space is freed."
                )
                self.paused = True
                continue
            # Get next task to process
            task = await self.queue_manager.fetch_next_task()
            if task is None:
                # No tasks currently available
                await asyncio.sleep(2)
                continue
            # Process the task
            await self._process_task(task)

    async def _process_task(self, task: DownloadTask) -> None:
        """Handle downloading a single task with retry/backoff logic."""
        task_id = task.id
        url = task.url
        self.logger.info(f"Starting download: task_id={task_id}, url={url}")
        try:
            file_path = await self._download(url, task_id)
            if not file_path:
                raise RuntimeError("Unknown download error: no file path returned")
            await self.queue_manager.mark_completed(task_id, file_path)
            self.logger.info(f"Download completed: task_id={task_id}, file={file_path}")
        except Exception as exc:
            self.logger.error(f"Download failed for task_id={task_id}: {exc}")
            # Determine whether to retry
            if task.attempts + 1 >= self.queue_manager.max_retries:
                await self.queue_manager.mark_failed(task_id, str(exc))
                self.logger.warning(f"Task {task_id} marked as permanently failed")
            else:
                # Reschedule with exponential backoff
                await self.queue_manager.reschedule_task(task_id, task.attempts + 1)
                self.logger.info(
                    f"Rescheduled task {task_id} (attempt {task.attempts + 1}/{self.queue_manager.max_retries})"
                )
        finally:
            # Remove from active tasks regardless of outcome
            self.active_tasks.pop(task_id, None)

    async def _download(self, url: str, task_id: int) -> Optional[str]:
        """Download a single URL using yt‑dlp in a background thread.

        Parameters
        ----------
        url: str
            The URL to download.
        task_id: int
            ID of the task in the queue; used to store progress.

        Returns
        -------
        Optional[str]
            The full path to the downloaded file, or ``None`` on error.
        """
        result = {"filepath": None}

        def progress_hook(info: dict) -> None:
            """Update progress information for this task based on yt‑dlp callbacks."""
            status = info.get("status")
            if status == "downloading":
                # info may contain '_percent_str', '_speed_str', '_eta_str'
                self.active_tasks[task_id] = {
                    "status": "downloading",
                    "progress": info.get("_percent_str", "0%"),
                    "speed": info.get("_speed_str", "?"),
                    "eta": info.get("_eta_str", "?"),
                }
            elif status == "finished":
                # Save the final filename; this callback runs before postprocessing
                result["filepath"] = info.get("filename")
                self.active_tasks[task_id] = {
                    "status": "finishing",
                    "progress": "100%",
                    "speed": info.get("_speed_str", "?"),
                    "eta": "0"
                }

        # Build yt‑dlp options
        ydl_opts = {
            "outtmpl": os.path.join(self.config.download_dir, "%(title).180s.%(ext)s"),
            "cookiefile": self.config.cookies_file,
            "quiet": True,
            "no_warnings": True,
            "merge_output_format": "mp4",
            "progress_hooks": [progress_hook],
            "noplaylist": True,
        }
        # When using aria2c, specify it as an external downloader. yt‑dlp will
        # fall back gracefully if aria2c is not installed. Only add the option
        # when enabled to avoid passing ``None`` which yt‑dlp does not accept.
        if self.config.use_aria2c:
            ydl_opts["external_downloader"] = "aria2c"

        def run_download() -> None:
            # This function runs in a separate thread, so it's safe to perform
            # blocking operations here.
            with YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])

        # Run the blocking download in an executor thread
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, run_download)
        return result.get("filepath")

    def get_active_status(self) -> Dict[int, Dict[str, str]]:
        """Return a snapshot of current active download statuses."""
        return dict(self.active_tasks)