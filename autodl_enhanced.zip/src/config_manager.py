"""Configuration loader for the Enhanced AutoDL Telegram Bot.

This module reads configuration values from a ``.env`` file (using
python‑dotenv) and constructs a Config object used by the rest of the
application. It also ensures that required directories exist and warns
about missing resources (e.g. the cookies file).
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import dotenv_values
from typing import Optional


@dataclass
class Config:
    token: str
    download_dir: str
    cookies_file: Optional[str]
    max_concurrent: int
    use_aria2c: bool
    log_level: str
    db_path: str
    logs_dir: str


def load_config(base_dir: str) -> Config:
    """Load configuration from ``config/.env`` relative to ``base_dir``.

    Parameters
    ----------
    base_dir: str
        The root directory of the project (where ``src`` and ``config`` live).

    Returns
    -------
    Config
        A dataclass containing all configuration values.

    Raises
    ------
    ValueError
        If required configuration keys are missing or invalid.
    """
    env_path = os.path.join(base_dir, "config", ".env")
    if not os.path.exists(env_path):
        raise ValueError(f"Missing .env file at {env_path}")

    env = dotenv_values(env_path)

    # Required keys
    token = env.get("TELEGRAM_BOT_TOKEN")
    if not token or token.startswith("<"):
        raise ValueError("TELEGRAM_BOT_TOKEN must be set in .env")

    download_dir = env.get("DOWNLOAD_DIR") or os.path.join(base_dir, "downloads")
    cookies_file = env.get("COOKIES_FILE") or None
    max_concurrent = int(env.get("MAX_CONCURRENT", 3))
    use_aria2c = str(env.get("USE_ARIA2C", "false")).lower() in {"1", "true", "yes"}
    log_level = env.get("LOG_LEVEL", "INFO")

    # Derived paths
    logs_dir = os.path.join(base_dir, "data", "logs")
    db_path = os.path.join(base_dir, "data", "queue", "queue.db")

    # Ensure directories exist
    os.makedirs(download_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    # Warn if cookies file does not exist
    if cookies_file and not os.path.exists(cookies_file):
        # We don't raise an exception here because downloading without cookies
        # may still be valid for public content. Loggers will warn the user.
        pass

    return Config(
        token=token,
        download_dir=download_dir,
        cookies_file=cookies_file,
        max_concurrent=max_concurrent,
        use_aria2c=use_aria2c,
        log_level=log_level,
        db_path=db_path,
        logs_dir=logs_dir,
    )