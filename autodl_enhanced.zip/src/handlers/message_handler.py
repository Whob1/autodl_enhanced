"""Telegram message handlers for the Enhanced AutoDL Telegram Bot.

This module defines handlers for plain text and document messages. It
extracts URLs from user input and enqueues them into the persistent
download queue. When a `.txt` file is uploaded, each line is treated
as a potential URL.
"""

from __future__ import annotations

from typing import List

from telegram import Update, Document
from telegram.ext import ContextTypes

from ..utils import validators


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming text messages containing one or more URLs."""
    message = update.message
    if message is None or not message.text:
        return
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    # Extract all URLs from the message text
    urls = validators.extract_urls(message.text)
    if not urls:
        await update.message.reply_text("Please send a valid URL or a .txt file containing URLs.")
        return
    added_ids: List[int] = []
    for url in urls:
        if validators.is_valid_url(url):
            task_id = await queue_manager.add_task(url)
            added_ids.append(task_id)
    if added_ids:
        await update.message.reply_text(
            f"📥 Added {len(added_ids)} task(s) to the queue."
        )
    else:
        await update.message.reply_text("No valid URLs found in your message.")


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle uploaded documents (.txt files) containing a list of URLs."""
    message = update.message
    if message is None or message.document is None:
        return
    document: Document = message.document
    if not document.file_name.lower().endswith('.txt'):
        await update.message.reply_text("Unsupported file type. Please send a .txt file.")
        return
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    # Download the file contents into memory
    try:
        file = await document.get_file()
        # download_to_memory is deprecated; use download_as_bytearray() in v21
        data: bytearray = await file.download_as_bytearray()
        content = data.decode('utf-8', errors='ignore')
    except Exception:
        await update.message.reply_text("Failed to download the file. Please try again.")
        return
    lines = [line.strip() for line in content.splitlines()]
    added = 0
    for line in lines:
        if validators.is_valid_url(line):
            await queue_manager.add_task(line)
            added += 1
    if added:
        await update.message.reply_text(f"📥 Added {added} task(s) from your file.")
    else:
        await update.message.reply_text("No valid URLs found in the uploaded file.")