"""Telegram command handlers for the Enhanced AutoDL Telegram Bot.

This module defines asynchronous handler functions for bot commands such
as /start, /queue, /status, /pause, /resume and /clear. Handlers rely on
objects stored in ``application.bot_data`` (queue_manager and
download_manager).
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict

from telegram import Update
from telegram.ext import ContextTypes

from ..utils import performance


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a welcome message when the user invokes /start."""
    message = (
        "👋 *Welcome to the Enhanced AutoDL Bot!*\n\n"
        "Send me a YouTube or other supported media link and I'll add it to the queue.\n"
        "You can also send a `.txt` file containing one URL per line.\n\n"
        "Commands:\n"
        "/queue – Show pending tasks\n"
        "/status – Show active downloads and system resource usage\n"
        "/pause – Pause all downloads\n"
        "/resume – Resume downloads if paused\n"
        "/clear – Clear permanently failed tasks"
    )
    await update.message.reply_markdown(message)


async def queue(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List pending tasks in the queue."""
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager not available.")
        return
    pending_tasks = await queue_manager.get_pending_tasks()
    if not pending_tasks:
        await update.message.reply_text("✅ The queue is empty.")
        return
    lines = [f"• Task {t.id}: {t.url} (attempts: {t.attempts})" for t in pending_tasks[:10]]
    more = "" if len(pending_tasks) <= 10 else f"\n…and {len(pending_tasks) - 10} more tasks"
    await update.message.reply_text(
        "📋 Pending tasks (showing up to 10):\n" + "\n".join(lines) + more
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Provide information about active downloads and system resources."""
    download_manager = context.bot_data.get("download_manager")
    queue_manager = context.bot_data.get("queue_manager")
    if download_manager is None or queue_manager is None:
        await update.message.reply_text("Status information unavailable.")
        return
    active = download_manager.get_active_status()
    processing_tasks = await queue_manager.get_processing_tasks()
    lines = []
    if active:
        lines.append("📥 *Active downloads:*\n")
        for task_id, info in active.items():
            line = (
                f"• Task {task_id}: {info.get('progress')}"
                f" at {info.get('speed')} (ETA: {info.get('eta')})"
            )
            lines.append(line)
    else:
        lines.append("📥 No active downloads.")
    # System performance
    cpu = performance.get_cpu_usage()
    mem = performance.get_memory_usage()
    disk = performance.get_disk_usage(download_manager.config.download_dir)
    sys_info = (
        f"\n*System resources*:\n"
        f"• CPU usage: {cpu:.1f}%\n"
        f"• Memory usage: {mem:.1f}%\n"
        f"• Disk usage: {disk:.1f}%"
    )
    await update.message.reply_markdown("\n".join(lines) + sys_info)


async def pause(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Pause all downloads and stop new tasks from starting."""
    download_manager = context.bot_data.get("download_manager")
    if download_manager is None:
        await update.message.reply_text("Download manager unavailable.")
        return
    download_manager.paused = True
    await update.message.reply_text("⏸️ Downloads have been paused.")


async def resume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Resume downloads if they are paused."""
    download_manager = context.bot_data.get("download_manager")
    if download_manager is None:
        await update.message.reply_text("Download manager unavailable.")
        return
    if not download_manager.paused:
        await update.message.reply_text("▶️ Downloads are already running.")
    else:
        download_manager.paused = False
        await update.message.reply_text("▶️ Downloads resumed.")


async def clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear permanently failed tasks from the queue."""
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    await queue_manager.clear_failed_tasks()
    await update.message.reply_text("🗑️ Cleared all failed tasks from the queue.")