"""SQLite-backed queue manager for the Enhanced AutoDL Telegram Bot.

This module implements a persistent task queue on top of SQLite. Each
task corresponds to a URL to be downloaded. The queue persists across
restarts and supports retrying failed tasks with exponential backoff.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Optional, List

import aiosqlite


@dataclass
class DownloadTask:
    """Represents a single download task stored in the SQLite queue."""

    id: int
    url: str
    status: str
    attempts: int
    added_at: float
    updated_at: float
    next_attempt_at: Optional[float]
    file_path: Optional[str]
    error_message: Optional[str]


class QueueManager:
    """Manage persistent download tasks using SQLite.

    Parameters
    ----------
    db_path: str
        Path to the SQLite database file.
    max_retries: int, optional
        Maximum number of retry attempts before marking a task as failed.
    base_delay: int, optional
        Base delay in seconds used for exponential backoff when
        calculating the next attempt time (e.g., 2**attempts * base_delay).
    """

    def __init__(self, db_path: str, max_retries: int = 3, base_delay: int = 60):
        self.db_path = db_path
        self.max_retries = max_retries
        self.base_delay = base_delay
        # Lock to prevent concurrent selection of the same task by multiple workers
        self._lock = asyncio.Lock()

    async def initialize(self) -> None:
        """Initialize the database and reset tasks stuck in processing state."""
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL,
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    added_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    next_attempt_at REAL,
                    file_path TEXT,
                    error_message TEXT
                )
                """
            )
            await conn.commit()
            # Reset tasks that were in processing state when the bot crashed
            await conn.execute(
                "UPDATE tasks SET status='pending' WHERE status='processing'"
            )
            await conn.commit()

    async def add_task(self, url: str) -> int:
        """Add a new task to the queue.

        Parameters
        ----------
        url: str
            The URL to download.

        Returns
        -------
        int
            The ID of the newly created task.
        """
        now = time.time()
        async with aiosqlite.connect(self.db_path) as conn:
            cursor = await conn.execute(
                """
                INSERT INTO tasks (url, status, attempts, added_at, updated_at)
                VALUES (?, 'pending', 0, ?, ?)
                """,
                (url, now, now),
            )
            await conn.commit()
            task_id = cursor.lastrowid
            return task_id

    async def _fetch_next_row(self, conn) -> Optional[DownloadTask]:
        """Select the next eligible task and mark it as processing.

        This helper must be called with the queue manager's lock held.
        """
        now = time.time()
        # Find the next task that is pending and ready for another attempt
        cursor = await conn.execute(
            """
            SELECT id, url, status, attempts, added_at, updated_at, next_attempt_at, file_path, error_message
            FROM tasks
            WHERE status='pending'
              AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
            ORDER BY id ASC
            LIMIT 1
            """,
            (now,),
        )
        row = await cursor.fetchone()
        if row is None:
            return None
        task = DownloadTask(*row)
        # Immediately mark as processing
        await conn.execute(
            "UPDATE tasks SET status='processing', updated_at=? WHERE id=?",
            (now, task.id),
        )
        await conn.commit()
        task.status = 'processing'
        task.updated_at = now
        return task

    async def fetch_next_task(self) -> Optional[DownloadTask]:
        """Fetch the next pending task and mark it as processing.

        Returns ``None`` if there are no pending tasks ready for processing.
        """
        async with self._lock:
            async with aiosqlite.connect(self.db_path) as conn:
                return await self._fetch_next_row(conn)

    async def mark_completed(self, task_id: int, file_path: str) -> None:
        """Mark a task as completed and record the output file path."""
        now = time.time()
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                "UPDATE tasks SET status='completed', file_path=?, updated_at=? WHERE id=?",
                (file_path, now, task_id),
            )
            await conn.commit()

    async def mark_failed(self, task_id: int, error_message: str) -> None:
        """Mark a task as failed (no more retries)."""
        now = time.time()
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                "UPDATE tasks SET status='failed', error_message=?, updated_at=? WHERE id=?",
                (error_message, now, task_id),
            )
            await conn.commit()

    async def reschedule_task(self, task_id: int, attempts: int) -> None:
        """Increment attempts and reschedule the task with exponential backoff."""
        # Compute next attempt time using exponential backoff (attempts start at 0)
        delay = (2 ** attempts) * self.base_delay
        next_time = time.time() + delay
        now = time.time()
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                """
                UPDATE tasks
                SET attempts = attempts + 1,
                    status = 'pending',
                    next_attempt_at = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (next_time, now, task_id),
            )
            await conn.commit()

    async def get_pending_tasks(self) -> List[DownloadTask]:
        """Return a list of tasks currently in the pending state."""
        async with aiosqlite.connect(self.db_path) as conn:
            cursor = await conn.execute(
                "SELECT id, url, status, attempts, added_at, updated_at, next_attempt_at, file_path, error_message
                 FROM tasks WHERE status='pending' ORDER BY id"
            )
            rows = await cursor.fetchall()
            return [DownloadTask(*row) for row in rows]

    async def get_processing_tasks(self) -> List[DownloadTask]:
        """Return a list of tasks currently in the processing state."""
        async with aiosqlite.connect(self.db_path) as conn:
            cursor = await conn.execute(
                "SELECT id, url, status, attempts, added_at, updated_at, next_attempt_at, file_path, error_message
                 FROM tasks WHERE status='processing' ORDER BY id"
            )
            rows = await cursor.fetchall()
            return [DownloadTask(*row) for row in rows]

    async def clear_failed_tasks(self) -> None:
        """Remove tasks that have permanently failed from the database."""
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute("DELETE FROM tasks WHERE status='failed'")
            await conn.commit()

    async def count_by_status(self, status: str) -> int:
        """Return the number of tasks with the given status."""
        async with aiosqlite.connect(self.db_path) as conn:
            cursor = await conn.execute(
                "SELECT COUNT(*) FROM tasks WHERE status=?", (status,)
            )
            result = await cursor.fetchone()
            return result[0] if result else 0