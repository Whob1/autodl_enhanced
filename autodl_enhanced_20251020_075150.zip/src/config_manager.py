import os
from dotenv import load_dotenv
from typing import List

# Always load .env from project root
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=os.path.abspath(env_path), override=True)


class Config:
    """Configuration object for the AutoDL bot."""

    def __init__(self, base_dir: str):
        """Initialize configuration from environment variables."""
        # Required settings
        token = os.getenv("TELEGRAM_BOT_TOKEN")
        if not token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN must be set in .env")
        self.token = token

        # Optional settings with defaults
        self.admin_ids: List[str] = os.getenv("TELEGRAM_ADMIN_IDS", "").split(",")
        self.download_dir = os.getenv("DOWNLOAD_DIR", "/mnt/sda/videos")
        self.log_level = os.getenv("LOG_LEVEL", "INFO")

        # Download manager settings
        self.max_concurrent = int(os.getenv("MAX_CONCURRENT", "8"))
        # Handle empty COOKIES_FILE by using default if empty string is set
        cookies_file_env = os.getenv("COOKIES_FILE")
        self.cookies_file = cookies_file_env if cookies_file_env else os.path.join(base_dir, "data", "cookies", "cookies.txt")
        self.use_aria2c = os.getenv("USE_ARIA2C", "true").lower() == "true"
        self.min_disk_space_gb = float(os.getenv("MIN_DISK_SPACE_GB", "50.0"))
        self.socket_timeout = int(os.getenv("SOCKET_TIMEOUT", "30"))
        self.max_retries = int(os.getenv("MAX_RETRIES", "5"))
        self.retry_sleep = int(os.getenv("RETRY_SLEEP", "1"))
        self.max_video_quality = os.getenv("MAX_VIDEO_QUALITY", "1080p")
        self.preferred_format = os.getenv("PREFERRED_FORMAT", "mp4")
        self.skip_hls = os.getenv("SKIP_HLS", "true").lower() == "true"
        self.skip_dash = os.getenv("SKIP_DASH", "true").lower() == "true"
        self.max_playlist_videos = int(os.getenv("MAX_PLAYLIST_VIDEOS", "10"))

        # Database path
        self.db_path = os.path.join(base_dir, "data", "queue", "autodl.db")


def load_config(base_dir: str):
    """Load configuration from environment variables."""
    return Config(base_dir)
