"""Disk monitoring utilities for the Enhanced AutoDL Telegram Bot.

This module exposes functions to monitor available disk space in the
download directory. When free space drops below a configurable
threshold (10 GB by default), downloads should be paused and the
administrator notified.
"""

from __future__ import annotations

import psutil


def get_free_space_bytes(path: str) -> int:
    """Return the free space in bytes for the filesystem containing ``path``.

    Parameters
    ----------
    path: str
        The path on the filesystem to inspect.

    Returns
    -------
    int
        The number of free bytes available to the current user.
    """
    usage = psutil.disk_usage(path)
    return usage.free


def is_low_disk(path: str, threshold_gb: float = 10.0) -> bool:
    """Determine whether the available disk space is below a threshold.

    Parameters
    ----------
    path: str
        The directory to check.
    threshold_gb: float, optional
        The minimum free space (in gigabytes) required. Defaults to 10 GB.

    Returns
    -------
    bool
        True if free space is less than the threshold, otherwise False.
    """
    free_bytes = get_free_space_bytes(path)
    free_gb = free_bytes / (1024 ** 3)
    return free_gb < threshold_gb