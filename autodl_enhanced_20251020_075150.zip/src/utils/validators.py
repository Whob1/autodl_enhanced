"""Validation utilities for the Enhanced AutoDL Telegram Bot.

This module contains helper functions used to validate user input,
specifically URLs provided via Telegram messages or files.
"""

from __future__ import annotations

import re
from urllib.parse import urlparse
from typing import List


_URL_REGEX = re.compile(
    r"https?://[^\s\r\n]+", re.IGNORECASE
)


def is_valid_url(url: str) -> bool:
    """Return True if the input string appears to be a valid URL.

    A URL is considered valid if it has a proper scheme (http or https)
    and a network location. This is a basic validation and does not
    guarantee that the URL is reachable.

    Parameters
    ----------
    url: str
        The URL to validate.

    Returns
    -------
    bool
        True if the URL appears to be valid, otherwise False.
    """
    if not url:
        return False
    parsed = urlparse(url)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def extract_urls(text: str) -> List[str]:
    """Extract all HTTP/HTTPS URLs from a block of text.

    Parameters
    ----------
    text: str
        The text from which to extract URLs.

    Returns
    -------
    List[str]
        A list of all URLs found in the text.
    """
    if not text:
        return []
    return _URL_REGEX.findall(text)