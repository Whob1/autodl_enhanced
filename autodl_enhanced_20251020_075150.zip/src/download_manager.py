"""Download manager for the Enhanced AutoDL Telegram Bot.

This module is responsible for pulling tasks from the queue and
downloading them using yt‑dlp. It supports concurrent downloads,
respects global pause/resume commands, implements retry logic with
exponential backoff and keeps track of progress for real‑time status
reporting.
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Dict, Optional

from yt_dlp import YoutubeDL

from .queue_manager import QueueManager, DownloadTask
from .utils import disk_monitor
from .utils.logger import get_logger
from .config_manager import load_config


def is_playlist_url(url: str) -> bool:
    """Check if URL is a playlist."""
    playlist_keywords = [
        'playlist', 'list=', 'playlist?list=', '/playlist/',
        'album', 'channel', 'user'
    ]
    url_lower = url.lower()
    return any(keyword in url_lower for keyword in playlist_keywords)


async def extract_playlist_urls(url: str, max_videos: int = None) -> list[str]:
    """Extract individual video URLs from a playlist URL."""
    try:
        # Use yt-dlp to extract playlist info without downloading
        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "extract_flat": True,  # Don't download, just extract URLs
            "age_limit": 99,  # Allow adult content
            "ignoreerrors": True,  # Continue on errors
            "playlistend": max_videos or 10,  # Always limit playlists
            "max_downloads": max_videos or 10,  # Additional limit
        }

        from yt_dlp import YoutubeDL
        with YoutubeDL(ydl_opts) as ydl:
            print(f"DEBUG: Extracting playlist info for {url} with max_videos={max_videos}")
            info = ydl.extract_info(url, download=False)

            if not info:
                print("DEBUG: No info returned from yt-dlp")
                return []

            # Handle different playlist structures
            if 'entries' in info:
                # Standard playlist
                entries = info['entries']
                print(f"DEBUG: Found {len(entries)} entries in playlist")
            elif isinstance(info, list):
                # Some extractors return list directly
                entries = info
                print(f"DEBUG: Info is list with {len(entries)} items")
            else:
                print(f"DEBUG: Unexpected info structure: {type(info)}")
                return []

            # Extract URLs from entries
            video_urls = []
            for i, entry in enumerate(entries):
                if isinstance(entry, dict):
                    video_url = entry.get('url') or entry.get('webpage_url')
                    if video_url:
                        video_urls.append(video_url)
                        print(f"DEBUG: Extracted URL {i+1}: {video_url[:60]}...")
                    else:
                        print(f"DEBUG: No URL found in entry {i+1}")
                elif isinstance(entry, str):
                    video_urls.append(entry)
                    print(f"DEBUG: String URL {i+1}: {entry[:60]}...")
                else:
                    print(f"DEBUG: Unexpected entry type {i+1}: {type(entry)}")

            limited_urls = video_urls[:max_videos] if max_videos else video_urls
            print(f"DEBUG: Returning {len(limited_urls)} URLs (limited from {len(video_urls)})")
            return limited_urls

    except Exception as e:
        print(f"Error extracting playlist URLs: {e}")
        return []


class DownloadManager:
    """Coordinate downloads for queued tasks.

    Parameters
    ----------
    queue_manager: QueueManager
        The queue manager responsible for persisting tasks.
    config: Config
        Loaded configuration with download directory, concurrency limit,
        cookie file, etc.
    """

    def __init__(self, queue_manager: QueueManager, config: Config):
        self.queue_manager = queue_manager
        self.config = config
        self.logger = get_logger(self.__class__.__name__)
        self.active_tasks: Dict[int, Dict[str, str]] = {}
        self.paused: bool = False
        self._workers: list[asyncio.Task] = []
        # To allow graceful shutdown
        self._stop_event = asyncio.Event()

    async def start(self) -> None:
        """Start worker tasks up to the configured concurrency limit."""
        # Reset stop flag
        self._stop_event.clear()
        self.logger.info(
            f"Starting download manager with {self.config.max_concurrent} workers"
        )
        for _ in range(self.config.max_concurrent):
            task = asyncio.create_task(self._worker_loop())
            self._workers.append(task)

    async def stop(self) -> None:
        """Signal all workers to stop and wait for them to finish."""
        self._stop_event.set()
        for worker in self._workers:
            worker.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()

    async def _worker_loop(self) -> None:
        """Continuously fetch and process tasks until stopped."""
        while not self._stop_event.is_set():
            # If paused, sleep briefly and retry
            if self.paused:
                await asyncio.sleep(2)
                continue
            # Check disk space before starting a new task
            if disk_monitor.is_low_disk(self.config.download_dir, self.config.min_disk_space_gb):
                self.logger.warning(
                    "Low disk space detected. Pausing downloads until space is freed."
                )
                self.paused = True
                continue
            # Get next task to process
            task = await self.queue_manager.fetch_next_task()
            if task is None:
                # No tasks currently available
                await asyncio.sleep(2)
                continue
            # Process the task
            self.logger.info(f"Worker starting task {task.id}: {task.url}")
            await self._process_task(task)

    async def _process_task(self, task: DownloadTask) -> None:
        """Handle downloading a single task with retry/backoff logic."""
        task_id = task.id
        url = task.url

        # Mark task as starting
        self.active_tasks[task_id] = {
            "status": "starting",
            "progress": "0%",
            "speed": "0 B/s",
            "eta": "?",
            "url": url
        }

        self.logger.info(f"Starting download: task_id={task_id}, url={url}")
        try:
            file_path = await self._download(url, task_id)
            if not file_path or file_path == "":
                self.logger.warning(f"No file path returned for task {task_id}, checking filesystem...")
                # Try to find the downloaded file
                try:
                    import glob
                    files = glob.glob(os.path.join(self.config.download_dir, "*"))
                    if files:
                        # Filter out aria2 control files and fragments
                        files = [f for f in files if not any(ext in f for ext in ['.aria2', '-Frag', '__temp'])]
                        # Get files modified in the last 5 minutes
                        recent_files = [f for f in files if (time.time() - os.path.getmtime(f)) < 300]
                        if recent_files:
                            file_path = max(recent_files, key=os.path.getmtime)
                            self.logger.info(f"Found recent file for task {task_id}: {file_path}")
                        else:
                            raise RuntimeError("No recent files found (after filtering fragments)")
                    else:
                        raise RuntimeError("No files in download directory")
                except Exception as e:
                    self.logger.error(f"Could not find downloaded file for task {task_id}: {e}")
                    raise RuntimeError(f"Download completed but file not found: {e}")

            # Mark as completed
            self.active_tasks[task_id] = {
                "status": "completed",
                "progress": "100%",
                "speed": "Done",
                "eta": "0",
                "url": url
            }

            await self.queue_manager.mark_completed(task_id, file_path)
            self.logger.info(f"Download completed: task_id={task_id}, file={file_path}")
        except Exception as exc:
            self.logger.error(f"Download failed for task_id={task_id}: {exc}")

            # Mark as failed
            self.active_tasks[task_id] = {
                "status": "failed",
                "progress": "0%",
                "speed": "Failed",
                "eta": "N/A",
                "url": url,
                "error": str(exc)
            }

            # Determine whether to retry
            if task.attempts + 1 >= self.queue_manager.max_retries:
                await self.queue_manager.mark_failed(task_id, str(exc))
                self.logger.warning(f"Task {task_id} marked as permanently failed")
            else:
                # Reschedule with exponential backoff
                await self.queue_manager.reschedule_task(task_id, task.attempts + 1)
                self.logger.info(
                    f"Rescheduled task {task_id} (attempt {task.attempts + 1}/{self.queue_manager.max_retries})"
                )
        finally:
            # Keep in active tasks for a short time so status can be seen
            await asyncio.sleep(2)
            self.active_tasks.pop(task_id, None)

    async def _download(self, url: str, task_id: int) -> Optional[str]:
        """Download a single URL using yt‑dlp in a background thread.

        Parameters
        ----------
        url: str
            The URL to download.
        task_id: int
            ID of the task in the queue; used to store progress.

        Returns
        -------
        Optional[str]
            The full path to the downloaded file, or ``None`` on error.
        """
        self.logger.info(f"_download called for task {task_id}: {url}")
        result = {"filepath": None}

        def progress_hook(info: dict) -> None:
            """Update progress information for this task based on yt‑dlp callbacks."""
            status = info.get("status")

            # Debug logging for all progress hook calls
            self.logger.debug(f"Progress hook called for task {task_id}: status={status}, info={info}")

            # Update task status based on yt-dlp progress
            if status == "downloading":
                # Extract progress information
                percent_str = info.get("_percent_str", "0%")
                speed_str = info.get("_speed_str", "0 B/s")
                eta_str = info.get("_eta_str", "?")

                # Clean up speed string
                if speed_str and speed_str != "?":
                    speed_str = speed_str.replace("/s", "/s").strip()

                self.active_tasks[task_id] = {
                    "status": "downloading",
                    "progress": percent_str,
                    "speed": speed_str,
                    "eta": eta_str,
                    "url": url
                }
                # Debug logging for progress updates
                if task_id % 10 == 0:  # Log every 10th update to avoid spam
                    self.logger.debug(f"Task {task_id} progress: {percent_str} at {speed_str}")
            elif status == "finished":
                # Save the final filename; try multiple sources
                filename = info.get("filename") or info.get("_filename") or ""

                # Ignore aria2 fragment/temp files - wait for final merge
                if filename and ('.aria2' in filename or '-Frag' in filename or '__temp' in filename):
                    self.logger.debug(f"Ignoring fragment/temp file for task {task_id}: {filename}")
                    return

                # If still no filename, try to find the actual file that was created
                if not filename:
                    try:
                        import glob
                        import os
                        # Look for the most recently modified file in download dir
                        files = glob.glob(os.path.join(self.config.download_dir, "*"))
                        if files:
                            # Filter out aria2 control files and fragments
                            files = [f for f in files if not any(ext in f for ext in ['.aria2', '-Frag', '__temp'])]
                            if files:
                                latest_file = max(files, key=os.path.getmtime)
                                # Check if it was modified recently (within last 60 seconds)
                                if (time.time() - os.path.getmtime(latest_file)) < 60:
                                    filename = latest_file
                    except:
                        pass

                result["filepath"] = filename or ""
                self.logger.info(f"Download finished for task {task_id}, filename: '{filename}'")

                self.active_tasks[task_id] = {
                    "status": "postprocessing",
                    "progress": "100%",
                    "speed": "Processing...",
                    "eta": "0",
                    "url": url
                }

        # Build yt‑dlp options with maximum performance optimizations
        ydl_opts = {
            "outtmpl": os.path.join(self.config.download_dir, "%(title).180s.%(ext)s"),
            "cookiefile": self.config.cookies_file,
            "quiet": True,
            "no_warnings": True,
            "merge_output_format": "mp4",
            "progress_hooks": [progress_hook],
            # Playlists are now handled at URL processing level
            # Maximum performance optimizations
            "concurrent_fragment_downloads": 16,  # Maximum concurrent fragments for speed
            "buffersize": 8*1024*1024,  # 8MB buffer for maximum I/O performance
            "retries": 3,  # Fast retries for speed
            "retry_sleep": 0,  # No sleep between retries for max speed
            "fragment_retries": 5,  # More fragment retries
            "http_chunk_size": 52428800,  # 50MB chunks for maximum throughput
            "socket_timeout": self.config.socket_timeout,  # Configurable connection timeout
            "continuedl": True,  # Continue partial downloads
            "noresizebuffer": True,  # Don't resize buffer dynamically
            "keepvideo": False,  # Don't keep video file after merging
            "nopart": True,  # Don't keep .part files
            "max_filesize": 100*1024*1024*1024,  # 100GB max file size
            "ratelimit": None,  # No rate limiting for maximum speed
            "throttledratelimit": None,  # No throttling
            "geo_bypass": True,  # Bypass geo restrictions
            "geo_bypass_country": "US",
            "extract_flat": False,  # Extract full info
            "youtube_include_dash_manifest": False,  # Skip DASH for faster processing
            "youtube_include_hls_manifest": False,  # Skip HLS for faster processing
            # Adult content handling
            "age_limit": 99,  # Allow all age-restricted content
            "ignore_no_formats_error": True,  # Continue even if some formats fail
            "ignoreerrors": False,  # Don't stop on individual video errors but allow fast failures
            # Quality and format optimizations
            "format": f"best[height<={self.config.max_video_quality.replace('p', '')}][ext={self.config.preferred_format}]/best[ext={self.config.preferred_format}]/best",
            "format_sort": [f"res:{self.config.max_video_quality.replace('p', '')}", f"ext:{self.config.preferred_format}", "size", "br"],
            "prefer_free_formats": False,  # Allow premium formats if available
            "youtube_skip_hls": self.config.skip_hls,  # Configurable HLS skipping
            "youtube_skip_dash": self.config.skip_dash,  # Configurable DASH skipping
            "extractor_retries": 3,  # Retry extractor failures
            "file_access_retries": 3,  # Retry file access issues
            "external_downloader_args": [
                "-x", "16",  # 16 connections for aria2c (optimized for speed)
                "-k", "1M",  # 1MB chunks for better throughput
                "-j", "4",   # 4 parallel downloads
                "--max-connection-per-server=8",
                "--min-split-size=1M",
                "--optimize-concurrent-downloads=true"
            ] if self.config.use_aria2c else None,
        }
        # When using aria2c, specify it as an external downloader. yt‑dlp will
        # fall back gracefully if aria2c is not installed. Only add the option
        # when enabled to avoid passing ``None`` which yt‑dlp does not accept.
        if self.config.use_aria2c:
            ydl_opts["external_downloader"] = "aria2c"

        def run_download() -> None:
            # This function runs in a separate thread, so it's safe to perform
            # blocking operations here.
            try:
                self.logger.info(f"Starting yt-dlp download for task {task_id}: {url}")
                with YoutubeDL(ydl_opts) as ydl:
                    # Extract info first to get expected filename
                    info = ydl.extract_info(url, download=True)

                    # After download, try to get the actual filename from info dict
                    if info and not result.get("filepath"):
                        # Try multiple sources for the filename
                        expected_filename = ydl.prepare_filename(info)
                        if expected_filename and os.path.exists(expected_filename):
                            result["filepath"] = expected_filename
                            self.logger.info(f"Captured filename from info dict for task {task_id}: {expected_filename}")
                        else:
                            # File might have been post-processed, check for .mp4 version
                            base, _ = os.path.splitext(expected_filename)
                            mp4_file = f"{base}.mp4"
                            if os.path.exists(mp4_file):
                                result["filepath"] = mp4_file
                                self.logger.info(f"Found post-processed file for task {task_id}: {mp4_file}")

                    self.logger.info(f"yt-dlp download completed for task {task_id} with result: 0")
            except Exception as e:
                self.logger.error(f"yt-dlp download failed for task {task_id}: {e}")
                raise

        # Run the blocking download in an executor thread
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, run_download)
        return result.get("filepath")

    def get_active_status(self) -> Dict[int, Dict[str, str]]:
        """Return a snapshot of current active download statuses."""
        return dict(self.active_tasks)