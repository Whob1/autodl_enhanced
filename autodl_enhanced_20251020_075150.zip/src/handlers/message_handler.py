"""Telegram message handlers for the Enhanced AutoDL Telegram Bot.

This module defines handlers for plain text and document messages. It
extracts URLs from user input and enqueues them into the persistent
download queue. When a `.txt` file is uploaded, each line is treated
as a potential URL.
"""

from __future__ import annotations

from typing import List

from telegram import Update, Document
from telegram.ext import ContextTypes

from ..utils import validators
from ..download_manager import is_playlist_url, extract_playlist_urls


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming text messages containing one or more URLs."""
    message = update.message
    if message is None or not message.text:
        return
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    # Extract all URLs from the message text
    urls = validators.extract_urls(message.text)
    if not urls:
        await update.message.reply_text("Please send a valid URL or a .txt file containing URLs.")
        return
    added_ids: List[int] = []
    duplicate_ids: List[int] = []
    total_videos = 0
    total_duplicates = 0

    for url in urls:
        if not validators.is_valid_url(url):
            continue

        # Check if this is a playlist URL
        if is_playlist_url(url):
            config = context.bot_data.get("config", None)
            max_videos = config.max_playlist_videos if config else 10
            await update.message.reply_text(f"🎵 Detected playlist URL, extracting videos from: {url[:50]}...")
            try:
                video_urls = await extract_playlist_urls(url, max_videos=max_videos)
                if video_urls:
                    await update.message.reply_text(f"📋 Found {len(video_urls)} videos in playlist")
                    for video_url in video_urls:
                        if validators.is_valid_url(video_url):
                            task_id, is_new = await queue_manager.add_task(video_url)
                            if is_new:
                                added_ids.append(task_id)
                                total_videos += 1
                            else:
                                duplicate_ids.append(task_id)
                                total_duplicates += 1
                else:
                    await update.message.reply_text(f"❌ Could not extract videos from playlist: {url[:50]}...")
            except Exception as e:
                await update.message.reply_text(f"❌ Error processing playlist {url[:50]}...: {str(e)}")
        else:
            # Regular video URL
            task_id, is_new = await queue_manager.add_task(url)
            if is_new:
                added_ids.append(task_id)
                total_videos += 1
            else:
                duplicate_ids.append(task_id)
                total_duplicates += 1

    # Build response message
    response_parts = []
    if added_ids:
        if total_videos > len(urls):
            response_parts.append(f"📥 Added {total_videos} new video(s) (expanded from {len(urls)} URL(s))")
        else:
            response_parts.append(f"📥 Added {len(added_ids)} new task(s)")

    if duplicate_ids:
        response_parts.append(f"♻️ Skipped {total_duplicates} duplicate(s)")

    if response_parts:
        await update.message.reply_text(" • ".join(response_parts))
    else:
        await update.message.reply_text("No valid URLs found in your message.")


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle uploaded documents (.txt files) containing a list of URLs."""
    message = update.message
    if message is None or message.document is None:
        return
    document: Document = message.document
    if not document.file_name.lower().endswith('.txt'):
        await update.message.reply_text("Unsupported file type. Please send a .txt file.")
        return
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    # Download the file contents into memory
    try:
        file = await document.get_file()
        # download_to_memory is deprecated; use download_as_bytearray() in v21
        data: bytearray = await file.download_as_bytearray()
        content = data.decode('utf-8', errors='ignore')
    except Exception:
        await update.message.reply_text("Failed to download the file. Please try again.")
        return
    lines = [line.strip() for line in content.splitlines()]
    added = 0
    duplicates = 0
    total_videos = 0

    for line in lines:
        if not validators.is_valid_url(line):
            continue

        # Check if this is a playlist URL
        if is_playlist_url(line):
            config = context.bot_data.get("config", None)
            max_videos = config.max_playlist_videos if config else 10
            await update.message.reply_text(f"🎵 Processing playlist from file: {line[:50]}...")
            try:
                video_urls = await extract_playlist_urls(line, max_videos=max_videos)
                if video_urls:
                    await update.message.reply_text(f"📋 Found {len(video_urls)} videos in playlist")
                    for video_url in video_urls:
                        if validators.is_valid_url(video_url):
                            _, is_new = await queue_manager.add_task(video_url)
                            if is_new:
                                added += 1
                                total_videos += 1
                            else:
                                duplicates += 1
                else:
                    await update.message.reply_text(f"❌ Could not extract videos from playlist: {line[:50]}...")
            except Exception as e:
                await update.message.reply_text(f"❌ Error processing playlist {line[:50]}...: {str(e)}")
        else:
            # Regular video URL
            _, is_new = await queue_manager.add_task(line)
            if is_new:
                added += 1
                total_videos += 1
            else:
                duplicates += 1

    # Build response message
    response_parts = []
    if added:
        if total_videos > len([l for l in lines if l.strip()]):
            response_parts.append(f"📥 Added {total_videos} new video(s) (expanded from file)")
        else:
            response_parts.append(f"📥 Added {added} new task(s) from file")

    if duplicates:
        response_parts.append(f"♻️ Skipped {duplicates} duplicate(s)")

    if response_parts:
        await update.message.reply_text(" • ".join(response_parts))
    else:
        await update.message.reply_text("No valid URLs found in the uploaded file.")