"""Telegram command handlers for the Enhanced AutoDL Telegram Bot.

This module defines asynchronous handler functions for bot commands such
as /start, /queue, /status, /pause, /resume and /clear. Handlers rely on
objects stored in ``application.bot_data`` (queue_manager and
download_manager).
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict

from telegram import Update
from telegram.ext import ContextTypes

from ..utils import performance


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a welcome message when the user invokes /start."""
    message = (
        "👋 *Welcome to the Enhanced AutoDL Bot!*\n\n"
        "Send me a YouTube or other supported media link and I'll add it to the queue.\n"
        "You can also send a `.txt` file containing one URL per line.\n\n"
        "Commands:\n"
        "/queue – Show pending tasks\n"
        "/status – Show active downloads and system resource usage\n"
        "/pause – Pause all downloads\n"
        "/resume – Resume downloads if paused\n"
        "/retry – Retry all failed downloads\n"
        "/clear – Clear permanently failed tasks"
    )
    await update.message.reply_markdown(message)


async def queue(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List pending tasks in the queue."""
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager not available.")
        return
    pending_tasks = await queue_manager.get_pending_tasks()
    if not pending_tasks:
        await update.message.reply_text("✅ The queue is empty.")
        return
    lines = [f"• Task {t.id}: {t.url} (attempts: {t.attempts})" for t in pending_tasks[:10]]
    more = "" if len(pending_tasks) <= 10 else f"\n…and {len(pending_tasks) - 10} more tasks"
    await update.message.reply_text(
        "📋 Pending tasks (showing up to 10):\n" + "\n".join(lines) + more
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Provide information about active downloads and system resources."""
    download_manager = context.bot_data.get("download_manager")
    queue_manager = context.bot_data.get("queue_manager")
    if download_manager is None or queue_manager is None:
        await update.message.reply_text("Status information unavailable.")
        return
    active = download_manager.get_active_status()
    processing_tasks = await queue_manager.get_processing_tasks()

    # Get recent failed tasks (from last 10 minutes) - simplified approach
    recent_failed = []
    try:
        # Query failed tasks directly from database
        import sqlite3
        import time
        db_path = queue_manager.db_path
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        current_time = time.time()

        cursor.execute("""
            SELECT id, url, status, attempts, added_at, updated_at, next_attempt_at, file_path, error_message
            FROM tasks
            WHERE status='failed' AND updated_at > ?
            ORDER BY updated_at DESC
            LIMIT 5
        """, (current_time - 600,))  # Last 10 minutes

        for row in cursor.fetchall():
            task_id, url, status, attempts, added_at, updated_at, next_attempt_at, file_path, error_message = row
            # Create a simple object to hold the task info
            class SimpleTask:
                def __init__(self, id, url, error_message):
                    self.id = id
                    self.url = url
                    self.error_message = error_message
            recent_failed.append(SimpleTask(task_id, url, error_message))

        conn.close()
    except:
        pass  # Ignore if we can't get recent failed tasks

    lines = []

    if active:
        lines.append("📥 *Active downloads:*\n")
        for task_id, info in active.items():
            status = info.get('status', 'unknown')
            progress = info.get('progress', '0%')
            speed = info.get('speed', '?')
            eta = info.get('eta', '?')

            # Format URL to be shorter for display
            url = info.get('url', '')
            if len(url) > 50:
                url = url[:47] + "..."

            if status == 'failed':
                error_msg = info.get('error', '')
                if error_msg:
                    error_msg = f" - {error_msg[:30]}..."
                line = f"• Task {task_id}: ❌ FAILED{error_msg} - {url}"
            elif status == 'completed':
                line = f"• Task {task_id}: ✅ COMPLETED - {url}"
            elif status == 'starting':
                line = f"• Task {task_id}: 🔄 STARTING - {url}"
            elif status == 'postprocessing':
                line = f"• Task {task_id}: 🔄 POST-PROCESSING - {url}"
            else:
                line = f"• Task {task_id}: {progress} at {speed} (ETA: {eta})"

            lines.append(line)
    else:
        lines.append("📥 No active downloads.")

    # Show recent failed tasks
    if recent_failed:
        lines.append(f"\n❌ *Recent failures ({len(recent_failed)}):*")
        for task in recent_failed[:5]:  # Show up to 5 recent failures
            url_short = task.url[:40] + "..." if len(task.url) > 40 else task.url
            error_short = task.error_message[:30] + "..." if task.error_message and len(task.error_message) > 30 else (task.error_message or "Unknown error")
            lines.append(f"• Task {task.id}: {url_short} - {error_short}")

    # Show processing tasks count
    processing_count = len(processing_tasks) if processing_tasks else 0
    if processing_count > 0:
        lines.append(f"\n⚙️ {processing_count} tasks being processed")
    # System performance
    cpu = performance.get_cpu_usage()
    mem = performance.get_memory_usage()
    disk = performance.get_disk_usage(download_manager.config.download_dir)
    sys_info = (
        f"\n*System resources*:\n"
        f"• CPU usage: {cpu:.1f}%\n"
        f"• Memory usage: {mem:.1f}%\n"
        f"• Disk usage: {disk:.1f}%"
    )
    await update.message.reply_markdown("\n".join(lines) + sys_info)


async def pause(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Pause all downloads and stop new tasks from starting."""
    download_manager = context.bot_data.get("download_manager")
    if download_manager is None:
        await update.message.reply_text("Download manager unavailable.")
        return
    download_manager.paused = True
    await update.message.reply_text("⏸️ Downloads have been paused.")


async def resume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Resume downloads if they are paused."""
    download_manager = context.bot_data.get("download_manager")
    if download_manager is None:
        await update.message.reply_text("Download manager unavailable.")
        return
    if not download_manager.paused:
        await update.message.reply_text("▶️ Downloads are already running.")
    else:
        download_manager.paused = False
        await update.message.reply_text("▶️ Downloads resumed.")


async def clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear permanently failed tasks from the queue."""
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return
    await queue_manager.clear_failed_tasks()
    await update.message.reply_text("🗑️ Cleared all failed tasks from the queue.")


async def retry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Retry all failed tasks."""
    queue_manager = context.bot_data.get("queue_manager")
    if queue_manager is None:
        await update.message.reply_text("Queue manager unavailable.")
        return

    retried_count = await queue_manager.retry_failed_tasks()

    if retried_count == 0:
        await update.message.reply_text("ℹ️ No failed tasks to retry.")
    else:
        await update.message.reply_text(f"🔄 Retrying {retried_count} failed task(s).")